package com.example.cashflowminimizer;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;

public class CashMinimizerGame extends Application {

    private int size = 2;
    private int[][] matrix = new int[size][size];
    private final TextArea resultArea = new TextArea();
    private final TextField lenderField = new TextField();
    private final TextField borrowerField = new TextField();
    private final TextField amountField = new TextField();
    private final Label matrixLabel = new Label();

    @Override
    public void start(Stage primaryStage) {
        // Input Section
        VBox inputSection = createInputSection();

        // Results Section
        VBox resultSection = createResultSection();

        // Main Layout
        HBox mainLayout = new HBox(20, inputSection, resultSection);
        mainLayout.setPadding(new Insets(10));
        mainLayout.setAlignment(Pos.CENTER);

        // Scene
        Scene scene = new Scene(mainLayout, 700, 400);
        primaryStage.setTitle("Cash Minimizer");
        primaryStage.setScene(scene);

        primaryStage.setFullScreen(true);
        primaryStage.show();
    }

    private VBox createInputSection() {
        Label lenderLabel = new Label("Lender:");
        Label borrowerLabel = new Label("Borrower:");
        Label amountLabel = new Label("Amount:");

        lenderField.setPromptText("Enter Lender ID");
        borrowerField.setPromptText("Enter Borrower ID");
        amountField.setPromptText("Enter Amount");

        Button addDebtButton = new Button("Add Debt");
        addDebtButton.setOnAction(e -> addDebt());

        Button minimizeButton = new Button("Minimize Transactions:");
        minimizeButton.setOnAction(e -> minimizeTransactions());

        VBox inputBox = new VBox(10, lenderLabel, lenderField, borrowerLabel, borrowerField, amountLabel, amountField, addDebtButton, minimizeButton, matrixLabel);
        inputBox.setPadding(new Insets(10));
        inputBox.setStyle("-fx-border-color: black; -fx-border-width: 2px; -fx-background-color: lightblue;");
        inputBox.setAlignment(Pos.CENTER);
        return inputBox;
    }

    private VBox createResultSection() {
        resultArea.setEditable(false);
        resultArea.setStyle("-fx-font-size: 14px;");
        resultArea.setPrefHeight(300);

        VBox resultBox = new VBox(10, new Label("Results:"), resultArea);
        resultBox.setPadding(new Insets(10));
        resultBox.setStyle("-fx-border-color: black; -fx-border-width: 2px; -fx-background-color: lightgreen;");
        return resultBox;
    }

    private void addDebt() {
        try {
            int lender = Integer.parseInt(lenderField.getText());
            int borrower = Integer.parseInt(borrowerField.getText());
            int amount = Integer.parseInt(amountField.getText());

            // Expand matrix if needed
            while (lender >= size || borrower >= size) {
                expandMatrix();
            }

            // Add debt to the matrix
            matrix[lender][borrower] += amount;

            // Display updated matrix
            displayMatrix();

            // Clear input fields
            lenderField.clear();
            borrowerField.clear();
            amountField.clear();
        } catch (NumberFormatException e) {
            resultArea.setText("Invalid input. Please enter valid numbers.");
        }
    }

    private void expandMatrix() {
        int newSize = size + 1;
        int[][] newMatrix = new int[newSize][newSize];
        for (int i = 0; i < size; i++) {
            System.arraycopy(matrix[i], 0, newMatrix[i], 0, size);
        }
        matrix = newMatrix;
        size = newSize;
    }

    private void displayMatrix() {
        StringBuilder sb = new StringBuilder("Current Debt Matrix:\n");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                sb.append(matrix[i][j]).append("\t");
            }
            sb.append("\n");
        }
        matrixLabel.setText(sb.toString());
    }

    private void minimizeTransactions() {
        int[] netBalance = new int[size];

        // Calculate net balances
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                netBalance[i] += matrix[j][i] - matrix[i][j];
            }
        }

        ArrayList<Integer> debtors = new ArrayList<>();
        ArrayList<Integer> creditors = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            if (netBalance[i] < 0) {
                debtors.add(i);
            } else if (netBalance[i] > 0) {
                creditors.add(i);
            }
        }

        StringBuilder result = new StringBuilder("Transactions:\n");
        int i = 0, j = 0;

        while (i < debtors.size() && j < creditors.size()) {
            int debtor = debtors.get(i);
            int creditor = creditors.get(j);
            int amount = Math.min(-netBalance[debtor], netBalance[creditor]);

            result.append("Person ").append(debtor).append(" pays Person ").append(creditor).append(": $").append(amount).append("\n");

            netBalance[debtor] += amount;
            netBalance[creditor] -= amount;

            if (netBalance[debtor] == 0) i++;
            if (netBalance[creditor] == 0) j++;
        }

        resultArea.setText(result.toString());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
